
#!/usr/bin/env python

def hello_world_func():
    print("Hello from TestMod")
